package com.example.tfg;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class TodosClientes extends AppCompatActivity {

    EditText todos, nombre;

    Button refrescar, filtrar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_todos_clientes);

        todos=findViewById(R.id.todosCLientes);
        nombre=findViewById(R.id.buscarPorMarca);

        filtrar=findViewById(R.id.buttonFiltrarNombre);

        refrescar=findViewById(R.id.buttonrefrescar);

        refrescar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Modelo objeto=new Modelo();
                Clientes datos=new Clientes();


                String pedidosInteresados= objeto.bucarTodosClientes(TodosClientes.this, datos);
                todos.setText(pedidosInteresados);
                //llamamos a la funcion de buscartodoslosclientes  y seteamos el campo con el resutado de la funcion


            }
        });

        filtrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Modelo objeto=new Modelo();
                Clientes datos=new Clientes();

                datos.setNombre(String.valueOf(nombre.getText()));
                //setemos el valor de nombre, con lo que el usuario ha escrito en el campo, despues al llamar la funcion le pasamos el valor.

                String filtradoPorNombre=objeto.buscarClientePorNombre(TodosClientes.this, datos);
                todos.setText(filtradoPorNombre);
                //llamamos a la funcion de buscartodoslosclientesporNombre  y seteamos el campo con el resutado de la funcion
            }
        });



    }
}