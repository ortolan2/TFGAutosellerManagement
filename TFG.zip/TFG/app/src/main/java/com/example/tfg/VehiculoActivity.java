package com.example.tfg;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Arrays;

public class VehiculoActivity extends AppCompatActivity {

    EditText  marca, model, aniomat, kmauto, precioauto;

    Button insertarauto, buscarauto, actualizarauto, borrar, vertodos;

    AutoCompleteTextView matriculaAuto;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vehiculo);

        matriculaAuto=findViewById(R.id.editTextMatricula);
        marca=findViewById(R.id.editTextMarca);
        model=findViewById(R.id.editTextModelo);
        aniomat=findViewById(R.id.editTextMatriculacion);
        kmauto=findViewById(R.id.editTextkm);
        precioauto=findViewById(R.id.editTextPrecio);

        insertarauto=findViewById(R.id.insertarVehiculo);
        buscarauto=findViewById(R.id.consultarVehiculo);
        actualizarauto=findViewById(R.id.actualizarVehiculo);
        borrar=findViewById(R.id.refrescar1);
        vertodos=findViewById(R.id.vertodos);



        Modelo objeto=new Modelo();
        Vehiculos datos1=new Vehiculos();
        String matriculaVehiculo=objeto.bucarTodosVehiculosMatricula2(VehiculoActivity.this, datos1);
        //creamos un string con el return de la funcion
        String [] matriculaVehiculoPartes=matriculaVehiculo.split(" ");
        //creamos un array separando el string anterior por cada espacio
        ArrayList<String> matriculas= new ArrayList<>(Arrays.asList(matriculaVehiculoPartes));
        //añadimos al arraylist los valores del Array anterior
        ArrayAdapter<String> adapta3=new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, matriculas);
        //creamos un arrayadapter donde pasamos el arraylist anterior
        matriculaAuto.setAdapter(adapta3);
        //adapatamos el autocompletetextview con el arrayadapter creado.


        insertarauto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Modelo objeto=new Modelo();
                Vehiculos datos=new Vehiculos();

                if (matriculaAuto.getText().length()==7 && marca.getText().length()!=0 && model.getText().length()!=0 && aniomat.getText().length()!=0 && kmauto.getText().length()!=0 && precioauto.getText().length()!=0){
                    //validamos que todos los campos esten rellenados
                    datos.setMatricula(String.valueOf(matriculaAuto.getText()));
                    datos.setMarca(String.valueOf(marca.getText()));
                    datos.setModelo(String.valueOf(model.getText()));
                    datos.setAnio(String.valueOf(aniomat.getText()));
                    datos.setKm(String.valueOf(kmauto.getText()));
                    datos.setPrecio(String.valueOf(precioauto.getText()));

                    int insertar=objeto.insertarVehiculo(VehiculoActivity.this, datos);

                    if (insertar==1){
                        //mostramos mensaje de que ha funcionado y vaciamos campos
                        Toast.makeText(VehiculoActivity.this, "Añadido Vehiculo", Toast.LENGTH_LONG).show();
                        matriculaAuto.setText("");
                        marca.setText("");
                        model.setText("");
                        aniomat.setText("");
                        kmauto.setText("");
                        precioauto.setText("");
                    }else{
                        //mostramos error de que la PK ya existe
                        Toast.makeText(VehiculoActivity.this, "Error al añadir el Vehiculo, matricula ya existente", Toast.LENGTH_LONG).show();
                    }
                }else{
                    //mostramos error de que algun campo esta vacio
                    Toast.makeText(VehiculoActivity.this, "Introduce correctamente todos los datos obligatorios", Toast.LENGTH_LONG).show();
                }
            }
        });

        buscarauto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Modelo objeto=new Modelo();
                Vehiculos datos=new Vehiculos();

                datos.setMatricula(String.valueOf(matriculaAuto.getText()));

                String buscar=objeto.buscarVehiculo(VehiculoActivity.this, datos);
                //alojamos en string el return de la funcion

                if (buscar.length()>4){
                    //validamos que el resultado es superior a las comas que devuelve
                    String [] resultado=buscar.split(",");
                    //ingresmos el return en una array separado por comas
                    marca.setText(resultado[0]);
                    model.setText(resultado[1]);
                    aniomat.setText(resultado[2]);
                    kmauto.setText(resultado[3]);
                    precioauto.setText(resultado[4]);
                    //alojamos en cada campo la posicion correspondiente de cada array
                }else{
                    //mostramos mensaje de que la consutal ha dado error
                    Toast.makeText(VehiculoActivity.this, "Vehiculo no encontrado, introduce una matricula correcta", Toast.LENGTH_LONG).show();
                }

            }
        });

        actualizarauto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Modelo objeto=new Modelo();
                Vehiculos datos=new Vehiculos();

                datos.setMatricula(String.valueOf(matriculaAuto.getText()));
                datos.setMarca(String.valueOf(marca.getText()));
                datos.setModelo(String.valueOf(model.getText()));
                datos.setAnio(String.valueOf(aniomat.getText()));
                datos.setKm(String.valueOf(kmauto.getText()));
                datos.setPrecio(String.valueOf(precioauto.getText()));

                String matriculaV=matriculaAuto.getText().toString();

                if (matriculaAuto.getText().length()==7 && marca.getText().length()!=0 && model.getText().length()!=0 && aniomat.getText().length()!=0 && kmauto.getText().length()!=0 && precioauto.getText().length()!=0){
                    //validamos que todos los campos estan rellenos
                    int actualizar=objeto.actualizarVehiculo(VehiculoActivity.this, datos);
                    if (actualizar==1){
                        Toast.makeText(VehiculoActivity.this, "Vehiculo actualizado", Toast.LENGTH_LONG).show();
                        matriculaAuto.setText("");
                        marca.setText("");
                        model.setText("");
                        aniomat.setText("");
                        kmauto.setText("");
                        precioauto.setText("");
                    }else{
                        Toast.makeText(VehiculoActivity.this, "Error al actualizar el vehiculo", Toast.LENGTH_LONG).show();
                    }
                }else{
                    Toast.makeText(VehiculoActivity.this, "Introduce correctamente todos los datos obligatorios", Toast.LENGTH_LONG).show();
                }

            }
        });

        borrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                matriculaAuto.setText("");
                marca.setText("");
                model.setText("");
                aniomat.setText("");
                kmauto.setText("");
                precioauto.setText("");
            }
        });

        vertodos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(VehiculoActivity.this, TodosVehiculos.class);
                startActivity(intent);
            }
        });


    }
}