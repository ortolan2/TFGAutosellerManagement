package com.example.tfg;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class TodosVehiculos extends AppCompatActivity {

    EditText todos, marca;

    Button refrescar, filtrar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_todos_vehiculos);

        todos=findViewById(R.id.todosVehiculos);
        marca=findViewById(R.id.buscarPorMarca);

        refrescar=findViewById(R.id.buttonrefrescar2);
        filtrar=findViewById(R.id.buttonFiltrarMarca);

        refrescar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Modelo objeto=new Modelo();
                Vehiculos datos=new Vehiculos();


                String pedidosInteresados= objeto.bucarTodosVehiculos(TodosVehiculos.this, datos);
                todos.setText(pedidosInteresados);
                //llamamos a la funcion y seteamos el campo con el return obtenido

            }
        });

        filtrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Modelo objeto=new Modelo();
                Vehiculos datos=new Vehiculos();

                datos.setMarca(String.valueOf(marca.getText()));
                //setemos al valor de Marca con lo introducido por el usuario en el campo, despues al llamar a la funcion le pasamos el valor,

                String filtradoPorMarca=objeto.buscarVehiculoporMarca(TodosVehiculos.this, datos);
                todos.setText(filtradoPorMarca);
                //llamamos a la funcion y seteamos el campo con el return obtenido
            }
        });
    }
}