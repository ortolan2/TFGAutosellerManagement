package com.example.tfg;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.MultiAutoCompleteTextView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;

public class PresupuestosActivity extends AppCompatActivity {

    EditText/* referenciaPedido, vendedorPedido,vehiculoPedido, clientePedido,*/ precioPedido, comentarios;

    AutoCompleteTextView vendedor, vehiculo, cliente, referencia;


    TextView fechaPedido;

    Spinner estadoPedido;
    Button agregarPedido, buscarPedido, actualizarPedido, borrar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_presupuestos);

        referencia=findViewById(R.id.editTextReferencia);
       // vendedorPedido=findViewById(R.id.editTextVendedor);
        vendedor=findViewById(R.id.editTextVendedor);
       // vehiculoPedido=findViewById(R.id.editTextMatriculaVehiculo);
        vehiculo=findViewById(R.id.editTextMatriculaVehiculo);
        //clientePedido=findViewById(R.id.editTextCliente);
        cliente=findViewById(R.id.editTextCliente);
        precioPedido=findViewById(R.id.editTextPVP);
        fechaPedido=findViewById(R.id.editTextFecha);
        estadoPedido=findViewById(R.id.editTextEstado);
        comentarios=findViewById(R.id.editTextComentarios);



        Modelo objeto=new Modelo();

        Usuarios datos=new Usuarios();
        String vendedoresAuto=objeto.bucarTodosVendedoresNombres(PresupuestosActivity.this, datos);
        String [] vendedoresAutosPartes=vendedoresAuto.split(" ");
        ArrayList<String> vendedores= new ArrayList<>(Arrays.asList(vendedoresAutosPartes));
        ArrayAdapter <String> adapta2=new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, vendedores);
        vendedor.setAdapter(adapta2);

        Vehiculos datos1=new Vehiculos();
        String matriculaVehiculo=objeto.bucarTodosVehiculosMatricula(PresupuestosActivity.this, datos1);
        String [] matriculaVehiculoPartes=matriculaVehiculo.split(" ");
        ArrayList<String> matriculas= new ArrayList<>(Arrays.asList(matriculaVehiculoPartes));
        ArrayAdapter<String>adapta3=new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, matriculas);
        vehiculo.setAdapter(adapta3);

        Clientes datos2=new Clientes();
        String telefonoCLiente= objeto.bucarTodosClientesTelefono(PresupuestosActivity.this, datos2);
        String [] telefonoClientePartes=telefonoCLiente.split(" ");
        ArrayList<String>telefonos= new ArrayList<>(Arrays.asList(telefonoClientePartes));
        ArrayAdapter<String>adapta4=new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, telefonos);
        cliente.setAdapter(adapta4);

        Pedidos datos3=new Pedidos();
        String referenciaPedido=objeto.buscarTodosPedidosReferencia(PresupuestosActivity.this, datos3);
        String[]referenciaPedidoPArtes=referenciaPedido.split(" ");
        ArrayList<String>referencias=new ArrayList<>(Arrays.asList(referenciaPedidoPArtes));
        ArrayAdapter<String>adapta5=new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, referencias);
        referencia.setAdapter(adapta5);

        //repetimos los mismo pasos en los tres autocompletetextview
        //creamos un string con el return de la funcion
        //creamos un array separando el string anterior por cada espacio
        //añadimos al arraylist los valores del Array anterior
        //creamos un arrayadapter donde pasamos el arraylist anterior
        //adapatamos el autocompletetextview con el arrayadapter creado.



        String [] valoresEstado={"vendido", "interesado", "rechazado"};
        ArrayAdapter<String> adapta=new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, valoresEstado);
        estadoPedido.setAdapter(adapta);

        agregarPedido=findViewById(R.id.insertarPedido);
        buscarPedido=findViewById(R.id.consultarPedido);
        actualizarPedido=findViewById(R.id.actualizarPedido);
        borrar=findViewById(R.id.Refrescar);

        agregarPedido.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Modelo objeto=new Modelo();
                Pedidos datos=new Pedidos();
                Clientes datos1=new Clientes();
                Vehiculos datos2=new Vehiculos();
                Usuarios datos3=new Usuarios();




                datos3.setUsuario(String.valueOf(vendedor.getText()));
                String vendedorCorrecto=objeto.buscar(PresupuestosActivity.this, datos3);
                //alojamos en string el resultado de la funcion
                datos2.setMatricula(String.valueOf(vehiculo.getText()));
                String vehiculoCorrecto=objeto.buscarVehiculo(PresupuestosActivity.this, datos2);
                //alojamos en string el resultado de la funcion
                datos1.setTelefono(String.valueOf(cliente.getText()));
                String clienteCorrecto=objeto.buscarCliente(PresupuestosActivity.this, datos1);;
                //alojamos en string el resultado de la funcion

                if (referencia.getText().length()!=0 && vendedor.getText().length()!=0 && vehiculo.getText().length()!=0 && cliente.getText().length()!=0 && precioPedido.getText().length()!=0 && fechaPedido.getText().length()!=0 && comentarios.getText().length()!=0/*&& estadoPedido.getText().length()!=0*/ ){
                   //validamos que todos los campos estan rellenados
                    if (clienteCorrecto.length()>2){
                        if (vehiculoCorrecto.length()>4){
                            if(vendedorCorrecto.length()!=0){
                                //validamos que el cliente, el vehiculo y el vendedor ya estan registrados
                                datos.setReferencia(String.valueOf(referencia.getText()));
                                //datos.setVendedor(String.valueOf(vendedorPedido.getText()));
                                datos.setVendedor(String.valueOf(vendedor.getText()));
                                datos.setVehiculo(String.valueOf(vehiculo.getText()));
                                datos.setCliente(String.valueOf(cliente.getText()));
                                datos.setPvp(String.valueOf(precioPedido.getText()));
                                datos.setFechaPresupuesto(String.valueOf(fechaPedido.getText()));
                                datos.setEstado(String.valueOf(estadoPedido.getSelectedItem()));
                                datos.setComentarios(String.valueOf(comentarios.getText()));

                                int insertar=objeto.insertarPedido(PresupuestosActivity.this, datos);

                                if (insertar==1){
                                    //mostramos mensaje de correcto y vaciamos campos
                                    Toast.makeText(PresupuestosActivity.this, "Añadido pedido", Toast.LENGTH_LONG).show();
                                    referencia.setText("");
                                    //vendedorPedido.setText("");
                                    vendedor.setText("");
                                    vehiculo.setText("");
                                    cliente.setText("");
                                    precioPedido.setText("");
                                    fechaPedido.setText("");
                                    comentarios.setText("");
                                }else{
                                    Toast.makeText(PresupuestosActivity.this, "Error al añadir el pedido, Referencia ya usada", Toast.LENGTH_LONG).show();
                                }


                            }else{
                                Toast.makeText(PresupuestosActivity.this, "Vendedor inexistente ", Toast.LENGTH_LONG).show();
                            }

                        }else{
                            Toast.makeText(PresupuestosActivity.this, "vehiculo inexistente", Toast.LENGTH_LONG).show();
                        }

                    }else{
                        Toast.makeText(PresupuestosActivity.this, "cliente inexistente ", Toast.LENGTH_LONG).show();
                    }

                }else{
                    Toast.makeText(PresupuestosActivity.this, "Introduce correctamente todos los datos obligatorios", Toast.LENGTH_LONG).show();
                }

            }
        });

        buscarPedido.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Modelo objeto=new Modelo();
                Pedidos datos=new Pedidos();

                datos.setReferencia(String.valueOf(referencia.getText()));

                String buscar=objeto.buscarPedido(PresupuestosActivity.this, datos);
                //alojamos en string el return de la funcion

                if (buscar.length()>6){
                    //indicamos que el resultado es mayor que todas las comas que tiene el return
                    String [] resultado=buscar.split(",");

                    //creamos array donde ingresamos el resultado de la consulta pero los separamos por las comas
                    //vendedorPedido.setText(resultado[0]);
                    vendedor.setText(resultado[0]);
                    vehiculo.setText(resultado[1]);
                    cliente.setText(resultado[2]);
                    precioPedido.setText(resultado[3]);
                    fechaPedido.setText(resultado[4]);
                    //estadoPedido.setOnItemSelectedListener(estado1);
                    comentarios.setText(resultado[6]);
                    Toast.makeText(PresupuestosActivity.this, resultado[5], Toast.LENGTH_LONG).show();
                    if (resultado[5].equals("vendido")){
                        actualizarPedido.setVisibility(View.INVISIBLE);
                    }else{
                        actualizarPedido.setVisibility(View.VISIBLE);
                    }


                }else{
                    //mostramo mensaje de error
                    Toast.makeText(PresupuestosActivity.this, "Presupuesto no encontrado, introduce una referencia correcta", Toast.LENGTH_LONG).show();
                }
            }
        });

        actualizarPedido.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Modelo objeto=new Modelo();
                Pedidos datos=new Pedidos();
                Clientes datos1=new Clientes();
                Vehiculos datos2=new Vehiculos();
                Usuarios datos3=new Usuarios();

                datos3.setUsuario(String.valueOf(vendedor.getText()));
                String vendedorCorrecto=objeto.buscar(PresupuestosActivity.this, datos3);
                datos2.setMatricula(String.valueOf(vehiculo.getText()));
                String vehiculoCorrecto=objeto.buscarVehiculo(PresupuestosActivity.this, datos2);
                datos1.setTelefono(String.valueOf(cliente.getText()));
                String clienteCorrecto=objeto.buscarCliente(PresupuestosActivity.this, datos1);;

                datos.setReferencia(String.valueOf(referencia.getText()));
                datos.setVendedor(String.valueOf(vendedor.getText()));
                datos.setVehiculo(String.valueOf(vehiculo.getText()));
                datos.setCliente(String.valueOf(cliente.getText()));
                datos.setPvp(String.valueOf(precioPedido.getText()));
                datos.setFechaPresupuesto(String.valueOf(fechaPedido.getText()));
                datos.setEstado(String.valueOf(estadoPedido.getSelectedItem()));
                datos.setComentarios(String.valueOf(comentarios.getText()));

                String referenciaV=referencia.getText().toString();

                if (referencia.getText().length()!=0 && vendedor.getText().length()!=0 && vehiculo.getText().length()!=0 && cliente.getText().length()!=0 && precioPedido.getText().length()!=0 && fechaPedido.getText().length()!=0 && comentarios.getText().length()!=0){

                //validamos que todos los campos estan rellenos
                    if (clienteCorrecto.length()>2){
                        if (vehiculoCorrecto.length()>4){
                            if (vendedorCorrecto.length()!=0){
                                //validamos que al modificar no se ingresen o cliente no registrao o vehiculo no registrado o vendedor no regstrado
                                int actualizar=objeto.actualizarPedido(PresupuestosActivity.this, datos);
                                if (actualizar==1){
                                    Toast.makeText(PresupuestosActivity.this, "Pedido actualizado", Toast.LENGTH_LONG).show();
                                    referencia.setText("");
                                    //vendedorPedido.setText("");
                                    vendedor.setText("");
                                    vehiculo.setText("");
                                    cliente.setText("");
                                    precioPedido.setText("");
                                    fechaPedido.setText("");
                                    comentarios.setText("");
                                }else{
                                    Toast.makeText(PresupuestosActivity.this, "Error al actualizar el pedido", Toast.LENGTH_LONG).show();
                                }

                            }else{
                                Toast.makeText(PresupuestosActivity.this, "vendedor inexistente", Toast.LENGTH_LONG).show();
                            }
                        }else{
                            Toast.makeText(PresupuestosActivity.this, "vehiculo inexistente", Toast.LENGTH_LONG).show();
                        }
                    }else {
                        Toast.makeText(PresupuestosActivity.this, "cliente inexistente", Toast.LENGTH_LONG).show();
                    }
                }else{
                    Toast.makeText(PresupuestosActivity.this, "Introduce correctamente todos los datos obligatorios", Toast.LENGTH_LONG).show();
                }
            }
        });

        borrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                referencia.setText("");
                //vendedorPedido.setText("");
                vendedor.setText("");
                vehiculo.setText("");
                cliente.setText("");
                precioPedido.setText("");
                fechaPedido.setText("");
                comentarios.setText("");
                actualizarPedido.setVisibility(View.VISIBLE);

            }
        });


        fechaPedido.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Calendar calen=Calendar.getInstance();//con estas variables indicamos lo que queremos sacar.
                int anio=calen.get(Calendar.YEAR);
                int mes=calen.get(Calendar.MONTH);
                int dia=calen.get(Calendar.DAY_OF_MONTH);

                DatePickerDialog fecha1=new DatePickerDialog(PresupuestosActivity.this, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                        int mescorrecto=month+1;

                        fechaPedido.setText(dayOfMonth+ " - "+mescorrecto+" - "+year);//para setear necesitamos las que nos pasa el metodo

                    }
                },anio, mes, dia);
                fecha1.show();
            }
        });




    }
}